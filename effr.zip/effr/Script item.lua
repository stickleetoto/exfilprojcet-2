local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local LootRemove = ReplicatedStorage:WaitForChild("LootRemove")

LootRemove.OnServerEvent:Connect(function(player, model)
	if not model or not model:IsDescendantOf(workspace) then return end
	if not model:IsA("Model") then return end

	-- �ߺ� ȹ�� ����: �±� ����
	CollectionService:RemoveTag(model, "loot")
	CollectionService:RemoveTag(model, "g17")
	CollectionService:RemoveTag(model, "MCX")
	CollectionService:RemoveTag(model, "m4a1")

	-- �������� �� ����
	model:Destroy()
end)
