-- ReplicatedStorage/HideoutViewportService.lua
-- ViewportFrame �ȿ��� ����(ȸ��/��/�д�) 3��Ī�� �����ϴ� �淮 ���
-- ���: local HVS = require(RS.HideoutViewportService)
--       local handle = HVS.Open(vpf, { minDist=2, maxDist=120, zoomSpeed=2.0, rotateSpeed=0.18, defaultPitchDeg=-20, defaultYawDeg=160 })
--       handle:Close()

local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local M = {}

-- �⺻��
local function defaults(opts)
	opts = opts or {}
	return {
		-- Ž�� ����
		sourceModel = opts.sourceModel,                   -- ����Ʈ�� ������ �ҽ�(������ �ڵ�Ž��)
		sourcePaths = opts.sourcePaths or {               -- �ڵ�Ž�� ���(������� �õ�)
			"Workspace.HideoutPreview.Hideout",
			"Workspace.Hideout",
			"ReplicatedStorage.HideoutPreview.Hideout",
			"ReplicatedStorage.Hideout"
		},
		focusPartNames = opts.focusPartNames or { "hideoutview", "HideoutView", "HIDEOUTVIEW" },

		-- ī�޶� ������
		fov = math.clamp(tonumber(opts.fov) or 70, 20, 120),
		defaultYawDeg = tonumber(opts.defaultYawDeg) or 160,      -- ��/��
		defaultPitchDeg = tonumber(opts.defaultPitchDeg) or -15,  -- ��/�Ʒ�(������ �����ٺ�)
		startDist = tonumber(opts.startDist),                     -- ������ bbox ������� ����

		-- �Ѱ�/����
		minDist = math.max(0.1, tonumber(opts.minDist) or 3.5),   -- �� �������� �� ��
		maxDist = math.max(tonumber(opts.maxDist) or 60, 5),      -- �� �ָ� ������ �� ��
		zoomSpeed = math.max(0.05, tonumber(opts.zoomSpeed) or 1.3),
		rotateSpeed = math.max(0.01, tonumber(opts.rotateSpeed) or 0.18),   -- ���콺 �̵��� ���� ȸ�� ����
		rotateSpeedY = tonumber(opts.rotateSpeedY),               -- ���� ����(������ rotateSpeed ���)
		panSpeed = math.max(0.001, tonumber(opts.panSpeed) or 0.05),

		-- ���Ѱ�
		pitchMinDeg = tonumber(opts.pitchMinDeg) or -80,
		pitchMaxDeg = tonumber(opts.pitchMaxDeg) or 30,
		freeYaw = (opts.freeYaw == nil) and true or not not opts.freeYaw,   -- true�� Yaw ������
		yawMinDeg = tonumber(opts.yawMinDeg) or -180,
		yawMaxDeg = tonumber(opts.yawMaxDeg) or 180,
	}
end

-- ���ڿ� ��η� �ν��Ͻ� ã��
local function getByPath(path)
	local cur = game
	for seg in string.gmatch(path, "[^%.]+") do
		cur = cur:FindFirstChild(seg)
		if not cur then return nil end
	end
	return cur
end

-- �ҽ� ��/���� ã��
local function findSource(opts)
	if opts.sourceModel and opts.sourceModel.Parent then
		return opts.sourceModel
	end
	for _, p in ipairs(opts.sourcePaths) do
		local inst = getByPath(p)
		if inst then return inst end
	end
	return nil
end

-- �ٿ���ڽ�(AABB) ���ϱ�(����/�� ��� ����)
local function computeBounds(root)
	local minV, maxV
	for _, d in ipairs(root:GetDescendants()) do
		if d:IsA("BasePart") then
			local cf, size = d.CFrame, d.Size
			local corners = {
				cf * Vector3.new( size.X/2,  size.Y/2,  size.Z/2),
				cf * Vector3.new( size.X/2,  size.Y/2, -size.Z/2),
				cf * Vector3.new( size.X/2, -size.Y/2,  size.Z/2),
				cf * Vector3.new( size.X/2, -size.Y/2, -size.Z/2),
				cf * Vector3.new(-size.X/2,  size.Y/2,  size.Z/2),
				cf * Vector3.new(-size.X/2,  size.Y/2, -size.Z/2),
				cf * Vector3.new(-size.X/2, -size.Y/2,  size.Z/2),
				cf * Vector3.new(-size.X/2, -size.Y/2, -size.Z/2),
			}
			for _, v in ipairs(corners) do
				if not minV then
					minV, maxV = v, v
				else
					minV = Vector3.new(math.min(minV.X, v.X), math.min(minV.Y, v.Y), math.min(minV.Z, v.Z))
					maxV = Vector3.new(math.max(maxV.X, v.X), math.max(maxV.Y, v.Y), math.max(maxV.Z, v.Z))
				end
			end
		end
	end
	if not minV then
		return CFrame.new(), Vector3.new(16,16,16) -- ���
	end
	local size = maxV - minV
	local center = (minV + maxV) / 2
	return CFrame.new(center), size
end

local function findFocusCF(root, focusNames)
	for _, n in ipairs(focusNames) do
		local part = root:FindFirstChild(n, true)
		if part and part:IsA("BasePart") then
			return part:GetPivot()
		end
	end
	-- ������ ��ü �߾�
	local cf = computeBounds(root)
	return cf
end

-- ī�޶� CFrame ���
local function camCFrame(targetCF, yawDeg, pitchDeg, dist)
	local yaw = math.rad(yawDeg)
	local pitch = math.rad(pitchDeg)
	local rot = CFrame.Angles(0, yaw, 0) * CFrame.Angles(pitch, 0, 0)
	local look = rot.LookVector
	local focusPos = targetCF.Position
	local camPos = focusPos - look * dist
	return CFrame.new(camPos, focusPos)
end

-- WorldModel ����(����Ʈ��)
local function ensureWorld(vpf)
	local world = vpf:FindFirstChild("World")
	if not world then
		world = Instance.new("WorldModel")
		world.Name = "World"
		world.Parent = vpf
	end
	return world
end

function M.Open(vpf, opts)
	assert(typeof(vpf) == "Instance" and vpf:IsA("ViewportFrame"), "HVS.Open: ViewportFrame �ʿ�")
	opts = defaults(opts)

	local world = ensureWorld(vpf)

	-- �ҽ� ����
	local src = findSource(opts)
	if not src then
		warn("[HVS] no source model (tried paths): ", table.concat(opts.sourcePaths, ", "))
	end

	local clone
	if src then
		clone = src:Clone()
		clone.Name = "Hideout"
		clone.Parent = world
	end

	-- ī�޶� ����
	local cam = Instance.new("Camera")
	cam.FieldOfView = opts.fov
	cam.Parent = world
	vpf.CurrentCamera = cam

	-- Ÿ��(������) CF
	local targetCF = clone and findFocusCF(clone, opts.focusPartNames) or CFrame.new()

	-- �ٿ�� ��� ���� �Ÿ�
	local bboxCF, bboxSize = clone and computeBounds(clone) or CFrame.new(), Vector3.new(32,32,32)
	local diag = bboxSize.Magnitude
	local startDist = math.clamp(opts.startDist or (diag * 0.45), opts.minDist, opts.maxDist)

	-- ����
	local state = {
		vpf = vpf,
		world = world,
		model = clone,
		camera = cam,
		targetCF = targetCF,
		dist = startDist,
		yawDeg = opts.defaultYawDeg,
		pitchDeg = math.clamp(opts.defaultPitchDeg, opts.pitchMinDeg, opts.pitchMaxDeg),
		opts = opts,
		conns = {},
		dragRMB = false,
		lastMouse = nil,
	}

	-- �Է� ���ε�
	state.conns[#state.conns+1] = UserInputService.InputBegan:Connect(function(input, gpe)
		if gpe then return end
		if input.UserInputType == Enum.UserInputType.MouseButton2 then
			state.dragRMB = true
			state.lastMouse = UserInputService:GetMouseLocation()
		end
	end)

	state.conns[#state.conns+1] = UserInputService.InputEnded:Connect(function(input, gpe)
		if input.UserInputType == Enum.UserInputType.MouseButton2 then
			state.dragRMB = false
		end
	end)

	state.conns[#state.conns+1] = UserInputService.InputChanged:Connect(function(input, gpe)
		if gpe then return end
		-- ��
		if input.UserInputType == Enum.UserInputType.MouseWheel then
			local delta = -input.Position.Z
			local speed = opts.zoomSpeed
			state.dist = math.clamp(state.dist + delta * -speed, opts.minDist, opts.maxDist)
		end
		-- ȸ��/�д�
		if input.UserInputType == Enum.UserInputType.MouseMovement and state.dragRMB then
			local pos = UserInputService:GetMouseLocation()
			local dx = pos.X - state.lastMouse.X
			local dy = pos.Y - state.lastMouse.Y
			state.lastMouse = pos

			if UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsKeyDown(Enum.KeyCode.RightShift) then
				-- �д��� Ÿ���� �̵� (ī�޶� �ƴ�)
				local yaw = math.rad(state.yawDeg)
				local right = Vector3.new(math.cos(yaw), 0, -math.sin(yaw))
				local up = Vector3.new(0,1,0)
				local scale = (opts.panSpeed) * (state.dist * 0.1 + 1)
				state.targetCF = state.targetCF + CFrame.new((-right * dx + up * dy) * scale)
			else
				local rsX = opts.rotateSpeed
				local rsY = opts.rotateSpeedY or opts.rotateSpeed
				state.yawDeg = state.yawDeg - dx * rsX
				state.pitchDeg = math.clamp(state.pitchDeg - dy * rsY, opts.pitchMinDeg, opts.pitchMaxDeg)
				if not opts.freeYaw then
					state.yawDeg = math.clamp(state.yawDeg, opts.yawMinDeg, opts.yawMaxDeg)
				end
			end
		end
	end)

	-- ���� ����
	state.conns[#state.conns+1] = RunService.RenderStepped:Connect(function()
		cam.CFrame = camCFrame(state.targetCF, state.yawDeg, state.pitchDeg, state.dist)
	end)

	-- �ڵ�
	local closed = false
	local handle = {}

	function handle:SetYawPitch(yawDeg, pitchDeg)
		if closed then return end
		state.yawDeg = yawDeg or state.yawDeg
		state.pitchDeg = math.clamp(pitchDeg or state.pitchDeg, opts.pitchMinDeg, opts.pitchMaxDeg)
	end

	function handle:SetDist(dist)
		if closed then return end
		state.dist = math.clamp(dist, opts.minDist, opts.maxDist)
	end

	function handle:Close()
		if closed then return end
		closed = true
		for _, c in ipairs(state.conns) do pcall(function() c:Disconnect() end) end
		if state.model then state.model:Destroy() end
		if cam then cam:Destroy() end
		if state.world and #state.world:GetChildren() == 0 then state.world:Destroy() end
	end

	return handle
end

return M
