--!strict
-- ���� ����ȭ: Ŭ�� ������ save/load + ������ Ŭ��κ��� Pull
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local DataStoreService  = game:GetService("DataStoreService")

local DS = DataStoreService:GetDataStore("EFR_Inventory_v1")

-- RemoteFunction Ÿ�� ���� ��ƿ
local function ensureRemoteFunction(name: string): RemoteFunction
	local existing = ReplicatedStorage:FindFirstChild(name)
	if existing then
		if not existing:IsA("RemoteFunction") then
			existing:Destroy()
		end
	end
	local rf = ReplicatedStorage:FindFirstChild(name) :: RemoteFunction?
	if not rf then
		rf = Instance.new("RemoteFunction")
		rf.Name = name
		rf.Parent = ReplicatedStorage
	end
	return rf :: RemoteFunction
end

-- Ŭ�� �ֵ� save/load
local RF = ensureRemoteFunction("InventorySnapshot")         -- Client �� Server
-- ���� �ֵ� pull
local PullRF = ensureRemoteFunction("InventorySnapshotPull") -- Server �� Client

-- DataStore retry helpers
local function trySet(key: string, value: any): boolean
	for i = 1, 5 do
		local ok, err = pcall(function()
			DS:SetAsync(key, value)
		end)
		if ok then return true end
		warn(("[InventoryStore] Set ����(%d): %s"):format(i, tostring(err)))
		task.wait(0.5 * i)
	end
	return false
end

local function tryGet(key: string): any
	for i = 1, 5 do
		local ok, res = pcall(function()
			return DS:GetAsync(key)
		end)
		if ok then return res end
		warn(("[InventoryStore] Get ����(%d): %s"):format(i, tostring(res)))
		task.wait(0.5 * i)
	end
	return nil
end

-- Ŭ�� save/load ��Ʈ��
RF.OnServerInvoke = function(player: Player, action: string, payload: any)
	local key = ("u:%d"):format(player.UserId)
	if action == "save" then
		if typeof(payload) ~= "table" then return false end
		return trySet(key, payload)
	elseif action == "load" then
		return tryGet(key)
	end
	return nil
end

-- �÷��̾� ���� ��: �ֽź� Pull �� ����(�����ϸ�)
Players.PlayerRemoving:Connect(function(plr)
	local key = ("u:%d"):format(plr.UserId)
	local snap: any = nil

	local ok, res = pcall(function()
		return PullRF:InvokeClient(plr) -- Ŭ�� ������ ��� ��û
	end)
	if ok and typeof(res) == "table" then
		snap = res
	end

	if snap then
		trySet(key, snap)
	end
end)

-- ���� ���� ��: ���� �����ִ� �������� Pull �� ����
game:BindToClose(function()
	local plist = Players:GetPlayers()
	for _, plr in ipairs(plist) do
		local key = ("u:%d"):format(plr.UserId)
		local snap: any = nil

		local ok, res = pcall(function()
			return PullRF:InvokeClient(plr)
		end)
		if ok and typeof(res) == "table" then
			snap = res
		end
		if snap then
			trySet(key, snap)
		end
	end
end)
