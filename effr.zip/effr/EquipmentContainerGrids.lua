--!strict
-- StarterPlayerScripts/EquipmentContainerGrids.lua
-- �����̳�(vest/backpack/securecontainer) �˾ƿ� �׸��� ����/����
-- ? SlotMapRegistry �� ���� ���Ըʰ� 1:1�� �����ϰ� ����(GridKey ǥ�� ���)
-- ? ��/�� ���� ����: UI �� (c-1, r-1) == �� (row=r, col=c)
-- ? UID(���� ������ ����ID) ������� GridKey�� ����� ��� ���� ������ ����

-- ========= ���� =========
local CELL_SIZE   = 40
local SLOT_PAD    = 8
local SCROLL_W    = 8

-- ?? ��Ÿ/���� �Ӽ��� �� ����/������ �⺻ ũ��� ����
local FALLBACK_DIM_BY_TAG = {
	backpack        = { cols = 6, rows = 8 }, -- 6SH118 ��
	vest            = { cols = 6, rows = 3 }, -- StrandHogg ��
	-- securecontainer�� ���� ��Ÿ�� Ȯ���� �����Ƿ� ����(	 �׳� ǥ�� ����)
}

-- tag key�� ����/����/��� ���� + �ҹ���
local function keyify(s: string?): string
	if typeof(s) ~= "string" then return "" end
	s = s:lower()
	s = s:gsub("[%s_%-]+", "") -- ����/����/��� ����
	return s
end

-- �����̳ʷ� �����ϴ� '���� Ű'
local CONTAINER_KEYS = {
	vest = true,
	backpack = true,
	securecontainer = true,
}

-- ========= Services =========
local Players           = game:GetService("Players")
local RunService        = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService       = game:GetService("HttpService")

local player       = Players.LocalPlayer
local guiRoot      = player:WaitForChild("PlayerGui"):WaitForChild("ScreenGui")
local inventoryGui = guiRoot:WaitForChild("InventoryGui")
local equipFrame   = inventoryGui:WaitForChild("EquipmentFrame")
local equipIngame  = inventoryGui:WaitForChild("Equipmentingame")

-- ������ (pcall ����)
local SlotMapRegistry:any = nil
pcall(function() SlotMapRegistry = require(ReplicatedStorage:WaitForChild("SlotMapRegistry")) end)

local GetStashData : RemoteFunction? = nil
pcall(function() GetStashData = ReplicatedStorage:WaitForChild("GetStashData") :: RemoteFunction end)

-- ========= ��ƿ =========
local function toLocal(container: GuiObject, abs: Vector2): Vector2
	return abs - container.AbsolutePosition
end

local function clampTo(container: GuiObject, pos: Vector2, size: Vector2): Vector2
	local maxX = container.AbsoluteSize.X - size.X
	local maxY = container.AbsoluteSize.Y - size.Y
	return Vector2.new(
		math.clamp(pos.X, 0, math.max(0, maxX)),
		math.clamp(pos.Y, 0, math.max(0, maxY))
	)
end

local function readFirstAttr(inst: Instance, keys: {string}): number?
	for _,k in ipairs(keys) do
		local v = inst:GetAttribute(k)
		if typeof(v) == "number" and v > 0 then return v end
	end
	return nil
end

-- �����̳� �Ӽ� Ű(���� Attribute�� ����)
local COL_KEYS = { "ContainerCols", "CapacityCols" }
local ROW_KEYS = { "ContainerRows", "CapacityRows" }

-- �����̳� �Ӽ� �б�: Slot/�ڽ� GUI���� ContainerRows/ContainerCols��
local function findCapacityFromLocal(slot: Frame): (number?, number?, boolean)
	local function scan(inst: Instance): (number?, number?, boolean)
		if inst:GetAttribute("IsContainer") == true then
			local c = readFirstAttr(inst, COL_KEYS)
			local r = readFirstAttr(inst, ROW_KEYS)
			if c and r then return c, r, true end
		end
		return nil, nil, false
	end

	-- 1) ���� ��ü
	local c, r, ok = scan(slot)
	if ok then return c, r, true end

	-- 2) �ڽ� GUI(������)
	for _,ch in ipairs(slot:GetChildren()) do
		if ch:IsA("GuiObject") then
			c, r, ok = scan(ch)
			if ok then return c, r, true end
		end
	end
	return nil, nil, false
end

-- ���� ��Ÿ���� �����̳� ������ ȹ��(����)
local function findCapacityFromServerByGui(g: GuiObject): (number?, number?, boolean)
	if not GetStashData then return nil, nil, false end

	local function guessName(inst: Instance): string?
		local n = inst:GetAttribute("ItemName")
		if typeof(n) == "string" and #n > 0 then return n end
		if inst.Name and #inst.Name > 0 then return inst.Name end
		return nil
	end

	local name: string? = guessName(g)
	local p = g.Parent
	while (not name) and p and p ~= inventoryGui do
		name = guessName(p); p = p.Parent
	end
	if not name then return nil, nil, false end

	local ok, data = pcall(function() return GetStashData:InvokeServer(name) end)
	if not ok or type(data) ~= "table" then return nil, nil, false end
	if data.IsContainer ~= true then return nil, nil, false end

	local cc = tonumber(data.ContainerCols)
	local rr = tonumber(data.ContainerRows)
	if cc and rr then return cc, rr, true end
	return nil, nil, false
end

-- ������ GUI���� UID(Id) ����
local function getEquippedUID(slot: Frame): string?
	local g = slot:FindFirstChildWhichIsA("ImageLabel") or slot:FindFirstChildWhichIsA("ViewportFrame")
	if not g then return nil end
	local id = g:GetAttribute("ItemUID") or g:GetAttribute("UID") or g:GetAttribute("Id")
	if typeof(id) == "string" and #id > 0 then return id end
	return nil
end

-- GridKey(ǥ��): SlotMapRegistry.MakeGridKey �� ������ �װ� ����, ������ ����
local function makeGridKey(tagKey:string, uid:string): string
	if SlotMapRegistry and typeof(SlotMapRegistry.MakeGridKey)=="function" then
		return SlotMapRegistry.MakeGridKey(tagKey, uid)
	end
	-- ����: grid:<tag>:<uid>
	return ("grid:%s:%s"):format(tagKey, uid)
end

-- ========= �˾ƿ� =========
local function ensurePopoutsFolder(): Folder
	local host = inventoryGui:FindFirstChild("SlotPopouts")
	if not host then
		host = Instance.new("Folder")
		host.Name = "SlotPopouts"
		host.Archivable = false
		host.Parent = inventoryGui
	end
	return host
end

local function ensurePopoutForSlot(tagKey: string): Frame
	local host = ensurePopoutsFolder()
	local key  = ("Popout_%s"):format(tagKey) -- �����̳� ������ 1��(���� 2�� ���� ����X)
	local pop  = host:FindFirstChild(key)
	if pop and pop:IsA("Frame") then return pop end

	pop = Instance.new("Frame")
	pop.Name = key
	pop.BackgroundTransparency = 0.1
	pop.BackgroundColor3 = Color3.fromRGB(40,40,40)
	pop.BorderSizePixel = 0
	pop.Visible = false
	pop.ZIndex = 50
	pop:SetAttribute("ContainerTag", tagKey)

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.BackgroundTransparency = 1
	title.Size = UDim2.new(1,-12,0,22)
	title.Position = UDim2.new(0,6,0,6)
	title.Font = Enum.Font.GothamBold
	title.TextSize = 16
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.TextColor3 = Color3.fromRGB(220,220,220)
	title.Text = (tagKey=="securecontainer" and "Secure Container")
		or (tagKey:sub(1,1):upper()..tagKey:sub(2))
	title.Parent = pop

	local area = Instance.new("Frame")
	area.Name = "GridArea"
	area.BackgroundTransparency = 1
	area.Position = UDim2.new(0,6,0,30)
	area.Size = UDim2.new(1,-12,1,-36)
	area.ClipsDescendants = true
	area.Parent = pop

	local sc = Instance.new("ScrollingFrame")
	sc.Name = "Scroll"
	sc.BackgroundTransparency = 1
	sc.ScrollBarThickness = SCROLL_W
	sc.Size = UDim2.fromScale(1,1)
	sc.ClipsDescendants = true
	sc.ScrollingEnabled = true
	sc.CanvasPosition = Vector2.new(0,0)
	if sc:GetAttribute("ItemBaseZ") == nil then sc:SetAttribute("ItemBaseZ", 60) end
	sc.Parent = area

	pop.Parent = host
	return pop
end

-- ��ǥ�� ����: ���� ������
local function updatePopoutPlacement(slot: GuiObject, pop: GuiObject, rows: number, cols: number)
	local w = math.max(220, cols * CELL_SIZE + 12)
	local h = 30 + rows * CELL_SIZE + 6
	pop.Size = UDim2.fromOffset(w, h)

	local sAbs  = slot.AbsolutePosition
	local sSize = slot.AbsoluteSize
	local raw   = Vector2.new(sAbs.X + sSize.X + SLOT_PAD, sAbs.Y)
	local cl    = clampTo(inventoryGui, toLocal(inventoryGui, raw), Vector2.new(w, h))
	pop.Position = UDim2.fromOffset(cl.X, cl.Y)
end

-- ���� �����(������ GUI ����)
local function clearOnlyCells(sc: ScrollingFrame)
	for _,ch in ipairs(sc:GetChildren()) do
		if ch:IsA("Frame") and string.sub(ch.Name, 1, 5) == "Cell_" then
			ch:Destroy()
		end
	end
end

local function buildPopoutGrid(slot: Frame, tagKey: string, rows: number, cols: number)
	local pop  = ensurePopoutForSlot(tagKey)
	local area = pop:FindFirstChild("GridArea") :: Frame
	local sc   = area and area:FindFirstChild("Scroll") :: ScrollingFrame
	if not sc then return end

	-- UID ���� GridKey(������ ����)
	local uid = getEquippedUID(slot)
	if not uid then
		pop.Visible = false
		pop:SetAttribute("HasContent", false)
		return
	end
	local gridKey = makeGridKey(tagKey, uid)

	-- ? SlotMapRegistry�� "��" ���� ���� ����(���� ��ó)
	local map:any = nil
	if SlotMapRegistry and typeof(SlotMapRegistry.Ensure)=="function" then
		map = SlotMapRegistry.Ensure(gridKey, rows, cols)
	else
		-- ���� ���� ȯ���: ���� Ű�� ��ȣ���ϸ� ���� map�� ������� ��
		SlotMapRegistry = SlotMapRegistry or {}
		SlotMapRegistry._maps = SlotMapRegistry._maps or {}
		map = SlotMapRegistry._maps[gridKey]
		if not map then
			local SlotMapManager = require(ReplicatedStorage:WaitForChild("SlotMapManager"))
			map = SlotMapManager.new(rows, cols)
			SlotMapRegistry._maps[gridKey] = map
		end
		map.rows, map.cols = rows, cols
	end

	-- Canvas/�Ӽ� ����ȭ (���̴� ��=�� �� 1:1)
	sc.CanvasPosition = Vector2.new(0,0)
	sc.CanvasSize = UDim2.new(0, map.cols * CELL_SIZE, 0, map.rows * CELL_SIZE)
	sc:SetAttribute("Rows", map.rows)
	sc:SetAttribute("Cols", map.cols)
	sc:SetAttribute("GridKey", gridKey)
	clearOnlyCells(sc)

	-- ��(�ð�ȭ) ����: (col-1, row-1)
	for r = 1, map.rows do
		for c = 1, map.cols do
			local cell = Instance.new("Frame")
			cell.Name  = string.format("Cell_%d_%d", r, c)
			cell.Size  = UDim2.fromOffset(CELL_SIZE, CELL_SIZE)
			cell.Position = UDim2.fromOffset((c - 1) * CELL_SIZE, (r - 1) * CELL_SIZE)
			cell.BackgroundColor3 = Color3.fromRGB(60,60,60)
			cell.BackgroundTransparency = 0.2
			cell.BorderSizePixel = 1
			cell.BorderColor3 = Color3.fromRGB(90,90,90)
			cell.ZIndex = (tonumber(sc:GetAttribute("ItemBaseZ")) or 60) - 1
			cell.Active = false
			cell.Parent = sc
		end
	end

	pop:SetAttribute("HasContent", true)
	updatePopoutPlacement(slot, pop, map.rows, map.cols)
	pop.Visible = equipIngame.Visible

	-- ��ġ ����
	local conn; conn = RunService.RenderStepped:Connect(function()
		if not slot:IsDescendantOf(inventoryGui) then conn:Disconnect(); return end
		updatePopoutPlacement(slot, pop, map.rows, map.cols)
	end)
end

-- ========= ���� =========
local function attachWatch(slotFrame: Frame, tagKey: string)
	local function rebuild()
		-- 1) ���� Attribute �켱
		local cols, rows, okLocal = findCapacityFromLocal(slotFrame)

		-- 2) ���� �� ���� ��Ÿ(���� GUI ����) ����
		if not okLocal or not cols or not rows then
			for _, ch in ipairs(slotFrame:GetChildren()) do
				if ch:IsA("GuiObject") then
					local sc, sr, ok = findCapacityFromServerByGui(ch)
					if ok and sc and sr then
						cols, rows = sc, sr
						okLocal = true
						break
					end
				end
			end
		end

		-- 3) �׷��� �� ã���� �±� ��� �⺻ ũ�� ��� (����/���� ���� ����)
		if not okLocal or not cols or not rows then
			local fb = FALLBACK_DIM_BY_TAG[tagKey]
			if fb then
				cols, rows = fb.cols, fb.rows
				okLocal = true
			end
		end

		if not okLocal or not cols or not rows then
			-- �����̳� �ƴ� �� �˾ƿ� ����
			local host = inventoryGui:FindFirstChild("SlotPopouts")
			if host then
				local pop = host:FindFirstChild(("Popout_%s"):format(tagKey))
				if pop and pop:IsA("Frame") then pop.Visible = false end
			end
			return
		end

		buildPopoutGrid(slotFrame, tagKey, rows, cols)
	end

	slotFrame.ChildAdded:Connect(rebuild)
	slotFrame.ChildRemoved:Connect(rebuild)
	for _,k in ipairs(COL_KEYS) do slotFrame:GetAttributeChangedSignal(k):Connect(rebuild) end
	for _,k in ipairs(ROW_KEYS) do slotFrame:GetAttributeChangedSignal(k):Connect(rebuild) end
	slotFrame:GetAttributeChangedSignal("IsContainer"):Connect(rebuild)

	task.defer(rebuild)
end

local function hookSlotsUnder(root: Instance)
	for _, d in ipairs(root:GetDescendants()) do
		if d:IsA("Frame") and d.Name == "Slot" then
			local parent = d.Parent
			-- �켱����: Slot.Attribute.Tag �� �θ� �̸�
			local tg = (d:GetAttribute("tag") or d:GetAttribute("Tag")) or (parent and parent.Name) or ""
			local tagKey = keyify(tg)
			if CONTAINER_KEYS[tagKey] then
				attachWatch(d, tagKey)
			end
		end
	end
	root.DescendantAdded:Connect(function(inst)
		if inst:IsA("Frame") and inst.Name == "Slot" then
			local parent = inst.Parent
			local tg = (inst:GetAttribute("tag") or inst:GetAttribute("Tag")) or (parent and parent.Name) or ""
			local tagKey = keyify(tg)
			if CONTAINER_KEYS[tagKey] then
				attachWatch(inst, tagKey)
			end
		end
	end)
end

-- ========= �ʱ�ȭ =========
hookSlotsUnder(equipFrame)
hookSlotsUnder(equipIngame)

-- �ΰ��� ���â ���� ���� �˾ƿ� ���̰�
equipIngame:GetPropertyChangedSignal("Visible"):Connect(function()
	local host = inventoryGui:FindFirstChild("SlotPopouts")
	if not host then return end
	for _, ch in ipairs(host:GetChildren()) do
		if ch:IsA("GuiObject") then ch.Visible = equipIngame.Visible and (ch:GetAttribute("HasContent") ~= false) end
	end
end)

-- (����) ���½�/���Ͽ��� GridKey �����صθ� �� ��Ȯ
do
	local stash = inventoryGui:FindFirstChild("ScrollingInventory")
	if stash and stash:IsA("ScrollingFrame") and not stash:GetAttribute("GridKey") then
		local key = (SlotMapRegistry and SlotMapRegistry.MakeGridKey and SlotMapRegistry.MakeGridKey("stash")) or "grid:stash"
		stash:SetAttribute("GridKey", key)
		if SlotMapRegistry and SlotMapRegistry.Get then
			local m = SlotMapRegistry.Get(key) or (SlotMapRegistry.Ensure and SlotMapRegistry.Ensure(key, 10, 30))
			if m then stash:SetAttribute("Rows", m.rows); stash:SetAttribute("Cols", m.cols) end
		else
			stash:SetAttribute("Rows", 10); stash:SetAttribute("Cols", 30)
		end
	end
	local pok = equipIngame:FindFirstChild("poket")
	if pok and pok:IsA("ScrollingFrame") and not pok:GetAttribute("GridKey") then
		local key = (SlotMapRegistry and SlotMapRegistry.MakeGridKey and SlotMapRegistry.MakeGridKey("pocket")) or "grid:pocket"
		pok:SetAttribute("GridKey", key)
		if SlotMapRegistry and SlotMapRegistry.Get then
			local m = SlotMapRegistry.Get(key) or (SlotMapRegistry.Ensure and SlotMapRegistry.Ensure(key, 4, 1))
			if m then pok:SetAttribute("Rows", m.rows); pok:SetAttribute("Cols", m.cols) end
		else
			pok:SetAttribute("Rows", 4); pok:SetAttribute("Cols", 1)
		end
	end
end
